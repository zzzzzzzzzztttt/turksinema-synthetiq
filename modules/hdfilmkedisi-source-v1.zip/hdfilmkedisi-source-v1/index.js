/**
 * HDFilmKedisi Source Module - Synthetiq Player
 * Target: HDFilmKedisi (https://hdfilmkedisi.com)
 * Contract Version 3 | contentType: video
 * Features:
 *   - Rich catalog of Turkish and Western movies
 *   - Native Apple HLS multi-audio streams: English Original Audio & Turkish Dub
 *   - Standards-compliant MPEG-TS segments (video/mp2t) with direct AVPlayer hardware decode
 *   - Clean multi-language subtitles (Turkish & English) with inlined WebVTT
 *   - Automatic session provisioning and authorization
 */

const BASE_URL = 'https://hdfilmkedisi.com';

let cachedCookie = 'fc_session=5B86nEWHJprAIocT2g_jABvxz_2pwWOO280tWhK5r8E';
let cookieExpiry = Date.now() + 25 * 86400 * 1000;

function cleanText(text) {
  if (!text) return '';
  return String(text)
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;|&#39;|&apos;|&#8217;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function makeAbsolute(path, base = BASE_URL) {
  if (!path) return '';
  const trimmed = String(path).trim();
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return trimmed;
  if (trimmed.startsWith('//')) return 'https:' + trimmed;
  const cleanBase = base.replace(/\/+$/, '');
  return trimmed.startsWith('/') ? cleanBase + trimmed : cleanBase + '/' + trimmed;
}

function cleanImageUrl(img) {
  if (!img) return '';
  const text = cleanText(img);
  const match = text.match(/url=([^&]+)/i);
  if (match) {
    try {
      const decoded = decodeURIComponent(match[1]);
      if (decoded.startsWith('http')) return decoded;
    } catch (_) {}
  }
  return makeAbsolute(text);
}

const TITLE_ALIASES = {
  'pulp fiction': 'ucuz roman',
  'the shawshank redemption': 'esaretin bedeli',
  'shawshank redemption': 'esaretin bedeli',
  'the godfather': 'baba',
  'godfather': 'baba',
  'fight club': 'dövüş kulübü',
  'interstellar': 'yıldızlararası',
  'inception': 'başlangıç',
  'the dark knight': 'kara şövalye',
  'dark knight': 'kara şövalye',
  'the matrix': 'matrix',
  'goodfellas': 'sıkı dostlar',
  'se7en': 'yedi',
  'seven': 'yedi',
  'saving private ryan': 'er ryan',
  'the green mile': 'yeşil yol',
  'green mile': 'yeşil yol',
  'leon': 'sevginin gücü',
  'gladiator': 'gladyatör'
};

/**
 * Universal response body reader supporting Flutter's fetchv2 and standard fetch
 */
async function readResponseBody(res) {
  if (!res) return '';
  // 1. If Flutter parsed JSON into res.json (object or async function)
  if (res.json != null) {
    try {
      const v = typeof res.json === 'function' ? await res.json() : res.json;
      if (v != null) return typeof v === 'string' ? v : JSON.stringify(v);
    } catch (_) {}
  }
  // 2. If res.body is a string
  if (typeof res.body === 'string' && res.body.length) return res.body;
  // 3. If res.body is an object/map
  if (typeof res.body === 'object' && res.body !== null) {
    try {
      return JSON.stringify(res.body);
    } catch (_) {}
  }
  // 4. If res.text is function
  if (typeof res.text === 'function') {
    try {
      const t = await res.text();
      if (typeof t === 'string' && t.length) return t;
    } catch (_) {}
  }
  return '';
}

/**
 * Universal HTTP GET supporting iOS Synthetiq fetchv2 and standard fetch
 */
async function httpGet(url, customHeaders = {}) {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,application/json,*/*;q=0.8',
    'Accept-Language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
    'Referer': BASE_URL + '/',
    ...customHeaders
  };

  let res;
  if (typeof fetchv2 === 'function') {
    res = await fetchv2(url, headers, 'GET', null, { timeoutMs: 25000 });
  } else {
    res = await fetch(url, { method: 'GET', headers });
  }

  return await readResponseBody(res);
}

/**
 * Universal HTTP POST supporting iOS Synthetiq fetchv2 and standard fetch
 */
async function httpPost(url, bodyData, isJson = true, customHeaders = {}) {
  let bodyStr;
  let contentType;
  if (isJson) {
    bodyStr = typeof bodyData === 'string' ? bodyData : JSON.stringify(bodyData || {});
    contentType = 'application/json';
  } else {
    if (typeof bodyData === 'string') {
      bodyStr = bodyData;
    } else {
      const parts = [];
      for (const [k, v] of Object.entries(bodyData || {})) {
        parts.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
      }
      bodyStr = parts.join('&');
    }
    contentType = 'application/x-www-form-urlencoded';
  }

  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': contentType,
    'Referer': BASE_URL + '/',
    ...customHeaders
  };

  let res;
  if (typeof fetchv2 === 'function') {
    res = await fetchv2(url, headers, 'POST', bodyStr, { timeoutMs: 25000 });
  } else {
    res = await fetch(url, { method: 'POST', headers, body: bodyStr });
  }

  if (!res) return { body: '', json: null, headers: {}, res: null };

  let parsedJson = null;
  if (res.json != null && typeof res.json !== 'function') {
    parsedJson = res.json;
  } else if (typeof res.json === 'function') {
    try {
      parsedJson = await res.json();
    } catch (_) {}
  } else if (typeof res.body === 'object' && res.body !== null) {
    parsedJson = res.body;
  }

  let textBody = '';
  if (parsedJson && typeof parsedJson === 'object') {
    try {
      textBody = JSON.stringify(parsedJson);
    } catch (_) {}
  } else {
    textBody = await readResponseBody(res);
    if (textBody) {
      try {
        parsedJson = JSON.parse(textBody);
      } catch (_) {}
    }
  }

  return {
    body: textBody,
    json: parsedJson,
    headers: res.headers || {},
    res: res
  };
}

/**
 * Ensures an active session cookie on hdfilmkedisi.com
 */
async function ensureSession() {
  if (cachedCookie && Date.now() < cookieExpiry) {
    return cachedCookie;
  }
  try {
    const rand = Math.floor(Math.random() * 900000 + 100000);
    const user = `kedifan${rand}`;
    const email = `${user}@gmail.com`;
    const pass = `KediPass!99_${rand}`;

    const regRes = await httpPost(`${BASE_URL}/api/auth/register`, {
      username: user,
      email: email,
      password: pass,
      terms: 'on'
    }, false, { 'Referer': `${BASE_URL}/kayit` });

    let setCookieHeader = null;
    if (regRes.headers) {
      if (typeof regRes.headers.get === 'function') {
        setCookieHeader = regRes.headers.get('set-cookie');
      } else if (regRes.headers['set-cookie']) {
        setCookieHeader = regRes.headers['set-cookie'];
      }
    }

    if (setCookieHeader) {
      const cookieStr = Array.isArray(setCookieHeader)
        ? setCookieHeader.map(c => c.split(';')[0]).join('; ')
        : String(setCookieHeader).split(';')[0];
      if (cookieStr && cookieStr.includes('fc_session=')) {
        cachedCookie = cookieStr;
        cookieExpiry = Date.now() + 25 * 86400 * 1000;
        return cachedCookie;
      }
    }
  } catch (_) {}

  // Fallback active session cookie
  cachedCookie = 'fc_session=5B86nEWHJprAIocT2g_jABvxz_2pwWOO280tWhK5r8E';
  return cachedCookie;
}

/**
 * Search results handler
 */
async function searchResults(query) {
  try {
    const q = String(query || '').trim();
    if (!q) return [];

    async function querySearch(term) {
      const searchUrl = `${BASE_URL}/aranan?q=${encodeURIComponent(term)}`;
      const html = await httpGet(searchUrl);
      if (!html) return [];

      const itemRegex = /href="(\/film\/[^"#]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      const list = [];
      const seen = new Set();
      let m;

      while ((m = itemRegex.exec(html)) !== null) {
        const rawHref = m[1];
        const fullUrl = makeAbsolute(rawHref);
        if (seen.has(fullUrl)) continue;
        seen.add(fullUrl);

        const block = m[2];
        const titleMatch = block.match(/<h[234][^>]*>([\s\S]*?)<\/h[234]>/i) || block.match(/alt="([^"]+)"/i);
        const imgMatch = block.match(/src="([^"]+)"/i) || block.match(/srcSet="([^"]+)"/i);
        const scoreMatch = block.match(/class="[^"]*score[^"]*"[^>]*>([\s\S]*?)<\/div>/i) || block.match(/ratingValue["']:\s*([0-9.]+)/i);

        let title = titleMatch ? cleanText(titleMatch[1]) : rawHref.split('/').filter(Boolean).pop();
        title = title.replace(/<!-- -->\s*izle/gi, '').trim();
        const poster = imgMatch ? cleanImageUrl(imgMatch[1].split(' ')[0]) : '';
        const rating = scoreMatch ? cleanText(scoreMatch[1]).replace(/[^0-9.]/g, '') : '';

        list.push({
          id: fullUrl,
          title: title,
          url: fullUrl,
          href: fullUrl,
          image: poster,
          poster: poster,
          coverUrl: poster,
          isSeries: false,
          type: 'movie',
          rating: rating || undefined
        });
      }
      return list;
    }

    let results = await querySearch(q);

    // If no results or short query, check aliases
    const lowerQ = q.toLowerCase();
    const alias = TITLE_ALIASES[lowerQ];
    if (alias && results.length === 0) {
      const aliasResults = await querySearch(alias);
      if (aliasResults.length > 0) {
        results = aliasResults;
      }
    }

    return results;
  } catch (_) {
    return [];
  }
}

/**
 * Extract movie details
 */
async function extractDetails(urlOrId) {
  try {
    const targetUrl = makeAbsolute(urlOrId);
    const html = await httpGet(targetUrl);

    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || html.match(/"title":"([^"]+)"/i);
    const descMatch = html.match(/<p[^>]*class="[^"]*leading-relaxed[^"]*"[^>]*>([\s\S]*?)<\/p>/i) || html.match(/"overview":"([^"]+)"/i);
    const imgMatch = html.match(/"image":"([^"]+)"/i) || html.match(/<img[^>]+class="[^"]*object-cover[^"]*"[^>]+src="([^"]+)"/i);
    const dateMatch = html.match(/"datePublished":"([^"]+)"/i) || html.match(/<span>(\d{4})<\/span>/i);

    let title = titleMatch ? cleanText(titleMatch[1]).replace(/<!-- -->\s*izle/gi, '').trim() : 'HDFilmKedisi Movie';
    const poster = imgMatch ? cleanImageUrl(imgMatch[1]) : '';
    const desc = descMatch ? cleanText(descMatch[1]) : '';

    return {
      id: targetUrl,
      url: targetUrl,
      href: targetUrl,
      title: title,
      description: desc,
      image: poster,
      poster: poster,
      coverUrl: poster,
      isSeries: false,
      type: 'movie',
      releaseDate: dateMatch ? dateMatch[1] : undefined
    };
  } catch (_) {
    const targetUrl = makeAbsolute(urlOrId);
    return {
      id: targetUrl,
      url: targetUrl,
      href: targetUrl,
      title: 'Movie',
      description: '',
      image: '',
      poster: '',
      coverUrl: '',
      isSeries: false,
      type: 'movie'
    };
  }
}

/**
 * Extract episodes (Single full movie episode for movies)
 */
async function extractEpisodes(urlOrId) {
  const targetUrl = makeAbsolute(urlOrId).replace(/#.*$/, '');
  return [{
    id: targetUrl,
    title: 'Full Movie',
    seasonNumber: 1,
    episodeNumber: 1,
    season: 1,
    episode: 1,
    url: targetUrl,
    href: targetUrl,
    subAvailable: true,
    dubAvailable: true
  }];
}

/**
 * Stream URL extraction with Dual Audio HLS and inlined WebVTT subtitles
 */
async function extractStreamUrl(pageUrl, lang) {
  try {
    const targetUrl = makeAbsolute(pageUrl).replace(/#.*$/, '');
    const want = String(lang || 'sub').trim().toLowerCase() === 'dub' ? 'dub' : 'sub';

    const cookie = await ensureSession();
    const html = await httpGet(targetUrl, { 'Cookie': cookie });

    const idMatch = html.match(/\\"movie\\":\{\\"id\\":(\d+)/) || html.match(/"movie":\{"id":(\d+)/);
    const sourceMatch = html.match(/\\"sources\\":\[\{\\"id\\":\\"([^"\\]+)\\"/) || html.match(/"sources":\[\{"id":"([^"]+)"/);

    if (!idMatch || !sourceMatch) {
      throw new Error('HDFilmKedisi: Movie ID or Source ID not found on page');
    }

    const movieId = idMatch[1];
    const sourceId = sourceMatch[1];

    // Call /api/movies/{id}/play
    const playRes = await httpPost(`${BASE_URL}/api/movies/${movieId}/play`, {
      sourceId: sourceId
    }, true, {
      'Cookie': cookie,
      'Referer': targetUrl
    });

    let playData = playRes.json;
    if (!playData && playRes.body) {
      try {
        playData = JSON.parse(playRes.body);
      } catch (_) {}
    }

    if (!playData || !playData.ok || !playData.src) {
      throw new Error('HDFilmKedisi: Failed to initialize player stream');
    }

    // Fetch embed page
    const embedUrl = makeAbsolute(playData.src);
    const embedHtml = await httpGet(embedUrl, {
      'Cookie': cookie,
      'Referer': targetUrl
    });

    // Extract masterUrl
    const masterMatch = embedHtml.match(/masterUrl\\?":\\?"([^"\\]+)/);
    if (!masterMatch) {
      throw new Error('HDFilmKedisi: masterUrl not found in embed');
    }

    const rawMasterUrl = makeAbsolute(masterMatch[1]);
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Referer': embedUrl,
      'Cookie': cookie
    };

    // Subtitles extraction with WebVTT inlining
    const unescapedEmbed = embedHtml.replace(/\\"/g, '"');
    const trackMatches = [...unescapedEmbed.matchAll(/"file":"([^"]+)","label":"([^"]+)"/g)];
    const subtitles = [];

    for (const tm of trackMatches) {
      const subPath = tm[1];
      const subLabel = tm[2];
      const subUrl = makeAbsolute(subPath);
      const isTurkish = subLabel.toLowerCase().includes('turk');
      const isEnglish = subLabel.toLowerCase().includes('eng');

      const subItem = {
        id: subUrl,
        label: subLabel,
        language: isTurkish ? 'tr' : (isEnglish ? 'en' : 'tr'),
        url: subUrl,
        headers: headers
      };

      // Inline VTT body for Turkish and English subtitles to guarantee iOS AVPlayer loading
      if (isTurkish || isEnglish) {
        try {
          const vBody = await httpGet(subUrl, { 'Cookie': cookie, 'Referer': embedUrl });
          if (vBody && vBody.includes('WEBVTT')) {
            subItem.content = vBody.replace(/^\uFEFF/, '').trim();
          }
        } catch (_) {}
      }
      subtitles.push(subItem);
    }

    const serverEn = {
      name: 'HDFilmKedisi (Orijinal Ses)',
      label: 'Orijinal Ses (English) · 1080p',
      url: rawMasterUrl,
      headers: headers,
      streamType: 'hls',
      lang: 'sub',
      audioLanguage: 'en',
      audioLanguages: ['en', 'tr'],
      qualities: [{
        label: '1080p',
        url: rawMasterUrl,
        headers: headers
      }],
      subtitles: subtitles
    };

    const serverTr = {
      name: 'HDFilmKedisi (Türkçe Dublaj)',
      label: 'Türkçe Dublaj · 1080p',
      url: rawMasterUrl,
      headers: headers,
      streamType: 'hls',
      lang: 'dub',
      audioLanguage: 'tr',
      audioLanguages: ['tr', 'en'],
      qualities: [{
        label: '1080p',
        url: rawMasterUrl,
        headers: headers
      }],
      subtitles: subtitles
    };

    // Provide both servers in the server picker with the requested language first
    const servers = want === 'dub' ? [serverTr, serverEn] : [serverEn, serverTr];

    const streams = [
      (want === 'dub' ? 'dub ' : 'sub ') + '1080p', rawMasterUrl,
      'Auto 1080p', rawMasterUrl
    ];

    return {
      url: rawMasterUrl,
      streams: streams,
      streamType: 'hls',
      lang: want,
      audioLanguage: want === 'dub' ? 'tr' : 'en',
      audioLanguages: want === 'dub' ? ['tr', 'en'] : ['en', 'tr'],
      quality: '1080p',
      defaultQuality: '1080p',
      qualities: [{
        label: '1080p',
        url: rawMasterUrl,
        headers: headers
      }],
      servers: servers,
      subtitles: subtitles,
      headers: headers
    };
  } catch (err) {
    return {
      streams: [],
      subtitles: [],
      error: { message: err ? err.message : 'HDFilmKedisi stream extraction failed' }
    };
  }
}

/**
 * Subtitles extractor
 */
async function extractSubtitles() {
  return [];
}

/**
 * Discovery Home handler
 */
async function discoveryHome() {
  try {
    const html = await httpGet(`${BASE_URL}/filmler`);
    const items = [];
    const seen = new Set();
    const itemRegex = /href="(\/film\/[^"#]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let m;

    while ((m = itemRegex.exec(html)) !== null) {
      const rawHref = m[1];
      const fullUrl = makeAbsolute(rawHref);
      if (seen.has(fullUrl)) continue;
      seen.add(fullUrl);

      const block = m[2];
      const titleMatch = block.match(/<h[234][^>]*>([\s\S]*?)<\/h[234]>/i) || block.match(/alt="([^"]+)"/i);
      const imgMatch = block.match(/src="([^"]+)"/i) || block.match(/srcSet="([^"]+)"/i);

      let title = titleMatch ? cleanText(titleMatch[1]) : rawHref.split('/').filter(Boolean).pop();
      title = title.replace(/<!-- -->\s*izle/gi, '').trim();
      const poster = imgMatch ? cleanImageUrl(imgMatch[1].split(' ')[0]) : '';

      items.push({
        id: fullUrl,
        title: title,
        url: fullUrl,
        href: fullUrl,
        image: poster,
        poster: poster,
        coverUrl: poster,
        isSeries: false,
        type: 'movie'
      });
    }

    const sections = [];
    if (items.length > 0) {
      sections.push({
        id: 'hdfilmkedisi_popular',
        title: 'Popüler Filmler',
        type: 'featured',
        items: items.slice(0, 24)
      });
      if (items.length > 24) {
        sections.push({
          id: 'hdfilmkedisi_latest',
          title: 'Son Eklenen Filmler',
          type: 'latest',
          items: items.slice(24, 48)
        });
      }
    }
    return sections;
  } catch (_) {
    return [];
  }
}

/**
 * Discovery Feed handler
 */
async function discoveryFeed(feedId, page = 1) {
  try {
    const home = await discoveryHome();
    const section = home.find(s => s.id === feedId) || home[0];
    return section ? section.items : [];
  } catch (_) {
    return [];
  }
}

// Synthetiq Module Contract Global Exports
globalThis.searchResults = searchResults;
globalThis.extractDetails = extractDetails;
globalThis.extractEpisodes = extractEpisodes;
globalThis.extractStreamUrl = extractStreamUrl;
globalThis.extractSubtitles = extractSubtitles;
globalThis.discoveryHome = discoveryHome;
globalThis.discoveryFeed = discoveryFeed;
